<?php
/*
اراعه شده توسط سورس کده 🗣
[ کص ننت اصکی بری منبع نزنی! ]
@Sourrce_kade
*/
/*
لطفا اسم بنده رو پاک نکنید تا قانون حفظ بشه و کسی اگربلدنیست ران کنه بیاد کانال و با نحوه کارکرد و اموزشش بتونه از سورس استفاده کنه عزیزان.
موفق باشید
*/
//bot token
$token = "  ";

//bot username
$usernamebot = "Jorat_hagighat_bbot";

//user id of spy group
$gp12 = '-1001476058795';

//Support group link
$link = "https://t.me/joinchat/KaLq9BfVJWPyyWbqKSeFVA";

//lock channel id
$channel = "@Source_Home";

//id of admins
$admins = [1=>"698542836",
2=>"00000",
3=>"00000"
];

//help text
$help_text = "متن راهنما و طریقه بازی";


//description == dont delete surce file , addres : folders : other and soalat

//dont edit ! !
$geter = array("حقیقت+18","حقیقت-18","جرعت+18","جرعت-18");

//==============-------------====================================||
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$text = $message->text;
$type = $update->message->chat->type;
$gpid = $message->chat->id;
$message_id = $update->message->message_id;
$fr = $message->from->first_name;
$ls = $message->from->last_name;
$from_id = $message->from->id;
$writing = $message->text;

$telegram_updates = array(base64_decode("2LPYp9iy2YbYr9mH"),base64_decode("L0NyZWF0b3I="),base64_decode("L2NyZWF0b3I="),base64_decode("Q3JlYXRvcg=="),base64_decode("Y3JlYXRvcg=="));
$getcount = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMembersCount?chat_id=$chat_id"),true);
$counter = $getcount['result'];
$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$channel&user_id=$from_id"));
$updateing = file_get_contents(base64_decode("2qnYp9mG2KfZhCDYs9mI2LHYsyDYrtmI2YbZhyAhINm+2LEg2KfYsiDYs9mI2LHYsyDZh9in2Yog2LHYqNin2Kog2YfYp9mKINiq2YTar9ix2KfZhdmKICEK2YTYt9mB2Kcg2K/YsSDaqdin2YbYp9mEINmF2Kcg2LnYttmIINi02YjZitivIApAc291cmNlX2hvbWUKaHR0cHM6Ly90Lm1lL3NvdXJjZV9ob21l"));
$tch = $truechannel->result->status;
//inline
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$data_id = $update->callback_query->id;
$messageid = $update->callback_query->message->message_id;

//files 
mkdir("admin");
mkdir("admin/other");
mkdir("admin/amar");
mkdir("admin/soalat");
$gp = file_get_contents("admin/amar/gp.txt");
$user = file_get_contents("admin/amar/user.txt");
$spgp = file_get_contents("admin/amar/spgp.txt");
$stats = file_get_contents("admin/amar/stats.txt");
//count top

$trt = file_get_contents("admin/soalat/jorat.txt");
$trt1 = file_get_contents("admin/soalat/haghi.txt");
$trt2 = file_get_contents("admin/soalat/haghi17.txt");
$trt3 = file_get_contents("admin/soalat/jorat17.txt");
//soalat top

$abay = file_get_contents("admin/other/Source_Home.txt");
$abay1 = file_get_contents("admin/other/Source_Home1.txt");
$abay2 = file_get_contents("admin/other/Source_Home2.txt");
$abay3 = file_get_contents("admin/other/Source_Home3.txt");
//other file top

$wrn = file_get_contents("admin/wrn.txt");
//wrn file top

//get files
$ex = explode("\n",$trt);
$co = count($ex) -1;
$rand = rand(1,$co)-1;
$hosts = $ex[$rand];

$ex1 = explode("\n",$trt1);
$co1 = count($ex1) -1;
$rand1 = rand(1,$co1)-1;
$hosts1 = $ex1[$rand1];

$ex2 = explode("\n",$trt2);
$co2 = count($ex2) -1;
$rand2 = rand(1,$co2)-1;
$hosts2 = $ex2[$rand2];

$ex3 = explode("\n",$trt3);
$co3 = count($ex3) -1;
$rand3 = rand(1,$co3)-1;
$hosts3 = $ex3[$rand3];
/*
اراعه شده توسط سورس کده 🗣
[ کص ننت اصکی بری منبع نزنی! ]
@Sourrce_kade
*/
?>