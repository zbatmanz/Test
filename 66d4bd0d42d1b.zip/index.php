<?php
/*
اراعه شده توسط سورس کده 🗣
[ کص ننت اصکی بری منبع نزنی! ]
@Sourrce_kade
*/
ob_start();
const API_KEY = '  ';
include('tng.php');
//===================
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function sendmessage($chat_id, $text){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>"MarkDown"
 ]);
 } 
//-//////
function ForwardMessage($chat_id,$from_chat,$message_id){
	bot('ForwardMessage',[
	'chat_id'=>$chat_id,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
	}
//====================
function save($filename, $data) {
    $file = fopen($filename, 'w');
    fwrite($file, $data);
    fclose($file);
}
//=======================
  $users = explode("\n",$user);
    if (!in_array($from_id,$users)){
        $myfile = fopen("admin/amar/user.txt", "a") or die("Unable to open file!");
        fwrite($myfile, "$from_id\n");
        fclose($myfile);
    }
  if($from_id != $chat_id) {
    if($type == "group") {
    $agp = explode("\n",$gp1);
    if (!in_array($chat_id,$agp)){
    $myfile0 = fopen("admin/amar/gp.txt", "a") or die("Unable to open file!");
    fwrite($myfile0, "$chat_id\n");
    fclose($myfile0);
    }
    } 
     if($type == "supergroup") {
    $aspgp = explode("\n",$spgp);
    if (!in_array($chat_id,$aspgp)){
    $myfile1 = fopen("admin/amar/spgp.txt", "a") or die("Unable to open file!");
    fwrite($myfile1, "$chat_id\n");
    fclose($myfile1);
    }
    }
    }
//==============Source_Home=================
if($tch != 'member' and $tch != 'creator' and $tch != 'administrator' and $type != "group" and $type != "supergroup"){
    
 bot('sendmessage',[
                'chat_id'=>$chat_id,
                'text'=>"برای استفاده از ربات وحمایت ما لطفا ابتدا در کانال زیر عضو شوید و سپس  /start را بفشارید❤️

🆔 $channel

با تشکر",
 
]);
}

elseif(preg_match('/^\/([Ss][Tt][Aa][Rr][Tt])/',$text)){
	if($type != "supergroup" & $type != "group"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💎به ربات جرعت حقیقت خوش آمدید من رو به یک گروه اضافه کنید تا بتوانید ب دوستانتان بازی کنید",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'inline_keyboard'=>[
              [
             ['text'=>"🍾 بازی در گپ",'url'=>"https://telegram.me/$usernamebot?startgroup=playgame"]
              ],
              [
              ['text'=>"اموزش",'callback_data'=>"a"]
              ],
			  [
              ['text'=>"پشتیبانی",'callback_data'=>"b"]
              ]
              ]
        ])
 ]);
}
else {
    if($counter > 2 and $chat_id != $gp12){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"😁❤️خیلی ممنون ازینکه ربات مارو برای بازی انتخاب کردید این ربات کلی سوال ها و دسته بندی ها داره لطفا از دکمه ها برای شروع بازی استفاده کنید
و توجه کنید جرعت حقیقته پس باید عمل کنید و جارنزنید😼",
 'parse_mode'=>"MarkDown",
   'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"حقیقت+18"],['text'=>"جرعت+18"]],
 [['text'=>"جرعت-18"],['text'=>"حقیقت-18"]]
 ],
              "resize_keyboard"=>true,
              "one_time_keyboard" => true
        ])
 ]);
 bot('sendMessage',[
 'chat_id'=>$gp12,
 'text'=>"گروه زیر نصب شد   : \n  $gpid \n $fr \n $ls",
 'parse_mode'=>"MarkDown",
 ]);
}else {
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"متاسفم ! تو گروه فقط منو تو هستیم .نمیتونیم دوتایی بازی کنیم (: لطفا یکی از دوستات رو جهت بازی بیار و من رو دوباره به گروه دعوت بده تا باهم بازی کنیم ",
 'parse_mode'=>"MarkDown"
 ]); 
  bot('leaveChat',[
 'chat_id'=>$chat_id
 ]);
}
    }
        }
//==============Sourrce_kade=----------=========================
elseif($text == "حقیقت+18"){
    if($type != "private"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$hosts1,
 'parse_mode'=>"html",
 ]);
 bot('sendMessage',[
 'chat_id'=>$gp12,
 'text'=>" $fr \n $text \n $hosts1",
 'parse_mode'=>"html",
 ]);
}
    }
elseif($text == "جرعت+18"){
    if($type != "private"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$hosts,
 'parse_mode'=>"html",
 ]);
 bot('sendMessage',[
 'chat_id'=>$gp12,
 'text'=>" $fr \n $text \n $hosts",
 'parse_mode'=>"html",
 ]);
    }
}
elseif($text == "حقیقت-18"){
    if($type != "private"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$hosts2,
 'parse_mode'=>"html",
 ]);
 bot('sendMessage',[
 'chat_id'=>$gp12,
 'text'=>" $fr \n $text \n $hosts2",
 'parse_mode'=>"html",
 ]);
}
    }
elseif($text == "جرعت-18"){
    if($type != "private"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$hosts3,
 'parse_mode'=>"html",
 ]);
 bot('sendMessage',[
 'chat_id'=>$gp12,
 'text'=>" $fr \n $text \n $hosts3",
 'parse_mode'=>"html",
 ]);
    
}
    }

elseif($update->message){
    if(!in_array($text,$geter)){
    if($chat_id != $gp12){
    if($type != "private"){
  ForwardMessage($gp12,$chat_id,$message_id);
}
    }
        }
            }

if($data == "b"){
bot('sendmessage',[
 'chat_id'=>$chatid,
  'message_id'=>$messageid,
 'text'=>"به گروه زیر بیایید: \n $link",
 'parse_mode'=>"html",
 ]);
}
if($data == "a"){
bot('sendmessage',[
 'chat_id'=>$chatid,
  'message_id'=>$messageid,
 'text'=>"$help_text",
 'parse_mode'=>"html",
 ]);
}
//=============-Sourrce_kade===================panel===============
elseif($text == "ربات"){
    if(in_array($from_id,$admins)){
        file_put_contents("admin/other/Source_Home.txt", "nulled");
          file_put_contents("admin/other/Source_Home1.txt", "nulled");
            file_put_contents("admin/other/Source_Home2.txt", "nulled");
              file_put_contents("admin/other/Source_Home3.txt", "nulled");
        file_put_contents("admin/amar/stats.txt","noe");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"جانم ادمین؟",
 'parse_mode'=>"MarkDown",
   'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"جرعت سکسی"],['text'=>"امار"]],
 [['text'=>"حقیقت سکسی"],['text'=>"پیام همگانی"]],
 [['text'=>"جرعت مثبت"],['text'=>"حقیقت مثبت"]],
  [['text'=>"لیست سوال ها+"],['text'=>"لیست سوال ها-"]],
 [['text'=>"clear count"],['text'=>"clear questions"]],
 [['text'=>"clear all"]]
 ],
 ])
 ]);
}
}

elseif($text == "امار"){
    if(in_array($from_id,$admins)){
    $users = explode("\n",$user);
    $amar = count($users) -1;
    $gps = explode("\n",$gp);
    $agps = count($gps) -1;
    $aspgp = explode("\n",$spgp);
    $aspgps = count($aspgp) -1;
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>"✅Bot Stats 

👥Users :  $amar

📨Groups :  $agps

💬Super Groups :  $aspgps

💎Lang : PHP",
        'reply_to_message_id'=>$message_id,
        'parse_mode'=>"MarkDown"
    ]);
}
    }
elseif($text == "پیام همگانی"){
        if(in_array($from_id,$admins)){
            if($type == "private"){
    file_put_contents("admin/amar/stats.txt","pmall");
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>"♻️بسیار خوب، پیام خودرا ارسال کنید تا به همه ارسال کنم:",
        'reply_to_message_id'=>$message_id,
        'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  ])
    ]);
}
    }
            }
            elseif($stats == "pmall") {
if($text != "ربات"){
	$member = fopen( "admin/amar/user.txt", 'r');
		while( !feof( $member)) {
 			$user = fgets( $member);
			if($text != null){
SendMessage($user,$text,"html");
    }	
    }
    SendMessage($chat_id,"sended all","html");
    file_put_contents("admin/amar/stats.txt","nono");
    }

}

elseif($text == "جرعت سکسی" ){
    if(in_array($from_id,$admins)){
      file_put_contents("admin/other/Source_Home.txt", "soal");
bot('sendmessage',[
 'chat_id'=>$chat_id,
  'message_id'=>$message_id,
 'text'=>"سوال را ارسال کنید :",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
     }
}
elseif($abay == 'soal'){
        if(in_array($from_id,$admins)){
    if($text != "ربات"){
    save("admin/soalat/jorat.txt","$trt\n$text");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ذخیره شد.",
 'parse_mode'=>"MarkDown",
 ]);
 file_put_contents("admin/other/Source_Home.txt", "nulled");
}
}
}
elseif($text == "جرعت مثبت" ){
       if(in_array($from_id,$admins)){
      file_put_contents("admin/other/Source_Home1.txt", "soal");
bot('sendmessage',[
 'chat_id'=>$chat_id,
  'message_id'=>$message_id,
 'text'=>"سوال را ارسال کنید :",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
     }
}
elseif($abay1 == 'soal'){
    if($text != "ربات"){
            if(in_array($from_id,$admins)){
    save("admin/soalat/jorat17.txt","$trt3\n$text");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ذخیره شد.",
 'parse_mode'=>"MarkDown",
 ]);
 file_put_contents("admin/other/Source_Home1.txt", "nulled");
}
}
}
elseif($text == "حقیقت مثبت" ){
         if(in_array($from_id,$admins)){
      file_put_contents("admin/other/Source_Home2.txt", "soal");
bot('sendmessage',[
 'chat_id'=>$chat_id,
  'message_id'=>$message_id,
 'text'=>"سوال را ارسال کنید :",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
     }
}
elseif($abay2 == 'soal'){
    if($text != "ربات"){
            if(in_array($from_id,$admins)){
    save("admin/soalat/haghi17.txt","$trt2\n$text");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ذخیره شد.",
 'parse_mode'=>"MarkDown",
 ]);
 file_put_contents("admin/other/Source_Home2.txt", "nulled");
}
}
}
elseif($text == "حقیقت سکسی" ){
        if(in_array($from_id,$admins)){
      file_put_contents("admin/other/Source_Home3.txt", "soal");
bot('sendmessage',[
 'chat_id'=>$chat_id,
  'message_id'=>$message_id,
 'text'=>"سوال را ارسال کنید :",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
}
}
elseif($abay3 == 'soal'){
    if($text != "ربات"){
            if(in_array($from_id,$admins)){
    save("admin/soalat/haghi.txt","$trt1\n$text");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ذخیره شد.",
 'parse_mode'=>"MarkDown",
 ]);
 file_put_contents("admin/other/Source_Home3.txt", "nulled");
}
}
}
elseif($text == "clear count"){
         if(in_array($from_id,$admins)){
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"آیا مطمعن هستید میخواهید تمام آمار ربات را پاکسازی کنید؟",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
               [['text'=>"yes clear023"]],
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
     }
}
elseif($text == "yes clear023"){
        if(in_array($from_id,$admins)){
    if($text != "ربات"){
   unlink("admin/amar/user.txt");
    unlink("admin/amar/spgp.txt");
     unlink("admin/amar/gp.txt");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"آمار با موفقیت پاکسازی و به 0 برگشت",
 'parse_mode'=>"MarkDown",
   'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"جرعت سکسی"],['text'=>"امار"]],
 [['text'=>"حقیقت سکسی"],['text'=>"پیام همگانی"]],
 [['text'=>"جرعت مثبت"],['text'=>"حقیقت مثبت"]],
   [['text'=>"لیست سوال ها+"],['text'=>"لیست سوال ها-"]],
 [['text'=>"clear count"],['text'=>"clear questions"]],
 [['text'=>"clear all"]]
 ],
 ])
 ]);
}
}
}
elseif(in_array($writing,$telegram_updates) == true){
   bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>base64_decode("$updateing"),
 'parse_mode'=>"html",
 ]); 
}
elseif($text == "clear questions"){
         if(in_array($from_id,$admins)){
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"آیا مطمعن هستید که میخواهید تمام سوالات را پاک سازی کنید؟",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
               [['text'=>"yes clear7612"]],
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
}
}
elseif($text == "yes clear7612"){
        if(in_array($from_id,$admins)){
    if($text != "ربات"){
   unlink("admin/soalat/jorat.txt");
    unlink("admin/soalat/haghi.txt");
     unlink("admin/soalat/jorat17.txt");
     unlink("admin/soalat/haghi17.txt");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"مجموعه سوالات پاک شدند و به 0 برگشتند",
 'parse_mode'=>"MarkDown",
   'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"جرعت سکسی"],['text'=>"امار"]],
 [['text'=>"حقیقت سکسی"],['text'=>"پیام همگانی"]],
 [['text'=>"جرعت مثبت"],['text'=>"حقیقت مثبت"]],
   [['text'=>"لیست سوال ها+"],['text'=>"لیست سوال ها-"]],
 [['text'=>"clear count"],['text'=>"clear questions"]],
 [['text'=>"clear all"]]
 ],
 ])
 ]);
}
}
}
elseif($text == "clear all"){
        if(in_array($from_id,$admins)){
    bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"آیا قصد پاک سازی {سوالات} , {امارها},{و دیگرفایل های واسط}  را دارید؟",
 'parse_mode'=>"html",
 'reply_markup'=>json_encode([
           'keyboard'=>[
               [['text'=>"yes clr all"]],
 [['text'=>"ربات"]]
 ],
  "resize_keyboard"=>true,
  
    ])
 ]);
}
}
elseif($text == "yes clr all"){
      if(in_array($from_id,$admins)){
    if($text != "ربات"){
 unlink("admin/soalat/jorat.txt");
    unlink("admin/soalat/haghi.txt");
     unlink("admin/soalat/jorat17.txt");
     unlink("admin/soalat/haghi17.txt");
      unlink("admin/amar/user.txt");
    unlink("admin/amar/spgp.txt");
     unlink("admin/amar/gp.txt");
      unlink("admin/other/Source_Home.txt");
      unlink("admin/other/Source_Home1.txt");
      unlink("admin/other/Source_Home2.txt");
      unlink("admin/other/Source_Home3.txt");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تمام فایل ها پاک شدند!!",
 'parse_mode'=>"MarkDown",
   'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
           'keyboard'=>[
 [['text'=>"جرعت سکسی"],['text'=>"امار"]],
 [['text'=>"حقیقت سکسی"],['text'=>"پیام همگانی"]],
 [['text'=>"جرعت مثبت"],['text'=>"حقیقت مثبت"]],
   [['text'=>"لیست سوال ها+"],['text'=>"لیست سوال ها-"]],
 [['text'=>"clear count"],['text'=>"clear questions"]],
 [['text'=>"clear all"]]
 ],
 ])
 ]);
}
}
}
elseif($text == 'لیست سوال ها+'){
       if(in_array($from_id,$admins)){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"جرعت ها⭕️ : \n $trt \n =========================== \n⭕️ حقیقت ها \n $trt1",
 'parse_mode'=>"MarkDown"
 ]);
}
}

elseif($text == 'لیست سوال ها-'){
       if(in_array($from_id,$admins)){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"جرعت ها⭕️ : \n $trt3 \n =========================== \n⭕️ حقیقت ها \n $trt2",
 'parse_mode'=>"MarkDown"
 ]);
}
}

elseif(strpos($text, 'اخطار')!== false){
    if($chat_id == $gp12){
 $text = str_replace('اخطار ','',$text);
   bot('sendmessage',[
  'chat_id'=>$text,
 'text'=>"ربات بیکاراست اگر استفاده نشود خارج میشود
 اخطار از سمت سرور!",
 'parse_mode'=>"MarkDown",
        ]);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"send wrn chat id successful",
 'parse_mode'=>"MarkDown",
 ]);
}
}
elseif(strpos($text, 'خروج')!== false){
    if($chat_id == $gp12){
 $text = str_replace('خروج ','',$text);
   bot('sendmessage',[
  'chat_id'=>$text,
 'text'=>"ربات بدلیل عدم استفاده از سوی سرور خارج میگردد",
 'parse_mode'=>"MarkDown",
        ]);
 bot('leaveChat',[
 'chat_id'=>$text
 ]);
   bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"ok!bot leaved",
 'parse_mode'=>"MarkDown",
 ]);
}
}
elseif($text == "راهنما"){
    if($chat_id == $gp12 or in_array($from_id,$admins)){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"راهنما به شرح زیر میباشد :

❌اخطار دادن
اخطار -10039498498

 ⭕️ خارج کردن ربات از گروه برای حفظ منابع سرور 
خروج -100389498389


⚙️ توجه :  (ایدی گروه  مورد نظر بعد از نصب ارسال میشود و قابل مشاهده است)",
 'parse_mode'=>"html"
 ]);
}
}

if (file_exists('error_log')) unlink('error_log');
/*
اراعه شده توسط سورس کده 🗣
[ کص ننت اصکی بری منبع نزنی! ]
@Sourrce_kade
*/
?>